var request = require('request');
var fs = require('fs');
var uuid = require('uuid');


const params = {
    uploadDataURL: "http://localhost:5000/uploads",
    runScanURL: "http://localhost:5002/scans",
    codePath: "./Sources.zip",
    scanBodyExample: {
        "scanID": "",
        "project": {
            "id": "test",
            "type": "upload",
            "handler": {
                "url": ""
            }
        },
        "config": [{
            "type": "sast",
            "value": {
                "presetName": "Default",
                "incremental": "true",
                "engineConfiguration": "<TODO> url to the engine configuration file",
                "extensions": "<TODO> url to the extensions file"
            }
        }]
    }
};


// uploadFile(function (body) {
//     console.log(body)
//     var scanBody = params.scanBodyExample;
//     scanBody.project.handler.url = body.URL;
//     scanBody.scanID = uuid.v1();
//     runScan(scanBody)
// });


getUploadURL()

// function runScan(scanData) {
//     request.post(params.runScanURL, {
//         json: scanData
//     }, (error, res, body) => {
//         if (error) {
//             console.error(error)
//             return
//         }
//         console.log(`statusCode: ${res.statusCode}`)
//         console.log(body)
//     })
//     console.log(scanData);
// }


function getUploadURL() {
    request.post("http://localhost/api/uploads", { json: {} }, (error, res, body) => {
        if (error) {
            console.error(error)
            return
        }
        else {
            console.log(body.url)
            // uploadFile(function (info) {
            //     console.log(info)
            // }, body.URL)
        }
    })
}


function uploadFile(onComplete, url) {
    var req = request.put(url, function (err, resp, body) {
        if (err) {
            console.log('Error!');
        } else {
            onComplete(body)
        }
    });
    var form = req.form();
    form.append('file', '<FILE_DATA>', {
        filename: 'Sources.zip',
        contentType: 'multipart/form-data'
    });
    form.append('sources', fs.createReadStream(params.codePath));
}





