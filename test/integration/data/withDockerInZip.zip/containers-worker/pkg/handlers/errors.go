package handlers

//goland:noinspection ALL
const (
	PrepareSaveDirErrCode = 2000011
	GetZipErrCode         = 2000021
	PrepareLogDirErrCode  = 2000031
	RunScanErrCode        = 2000101
	ConvertResultErrCode  = 2000201
	PublishResultErrCode  = 2000301
)
